package com.cg.service;



import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.HotelRepository;
import com.cg.entity.BookingDetails;
import com.cg.entity.Days;
import com.cg.entity.Hotel;
import com.cg.entity.RoomDetails;
import com.cg.entity.Users;

@Service
@Transactional
public class HotelServiceImpl implements HotelService{
	@Autowired
	private HotelRepository hotelRepository;

	

	@Override
	public Users save(Users user) {
		
		return hotelRepository.save(user) ;
	}

	@Override
	public int save(Days booking,String strdate,String strdate2,String hotelid1,String roomid1,String userid1,int days1) {
		// TODO Auto-generated method stub
		return hotelRepository.save(booking,strdate,strdate2,hotelid1,roomid1,userid1,days1);
	}


	@Override
	public Users check(Users user) {
		// TODO Auto-generated method stub
		return hotelRepository.check(user);
	}

	@Override
	public List<Hotel> loadAllhotels() {
		// TODO Auto-generated method stub
		return hotelRepository.loadAllhotels();
	}

	@Override
	public List<RoomDetails> loadAllrooms(String id) {
		// TODO Auto-generated method stub
		return hotelRepository.loadAllrooms(id);
	}

	@Override
	public List<BookingDetails> bookingstatus(String userid1, String hotelid1,
			String roomid1) {
		// TODO Auto-generated method stub
		return hotelRepository.bookingstatus(userid1, hotelid1, roomid1);
	}

	//------------------------ADMIN-------------------------------------
	
	@Override
	public boolean validate(String uName, String pass) {
		if (uName.equals("admin")&& pass.equals("admin")){
			System.out.println("bdzvchg");
			return true;
		}
		else{
			System.out.println("djhbvjh");
			return false;
		}
	}

	@Override
	public List<Hotel> viewAllHotels() {
		return hotelRepository.viewAllHotels();
	}

	@Override
	public List<RoomDetails> viewRooms(String hid) {
		return hotelRepository.viewRooms(hid);
	}

	@Override
	public Hotel addHotels(Hotel hotel) {
		
		return hotelRepository.addHotels(hotel);
	}

	@Override
	public boolean hotelCheck(String hid) {
		return hotelRepository.hotelCheck(hid);
	}

	@Override
	public List<BookingDetails> viewAllBookings(String hid) {
		
		return hotelRepository.viewAllBookings(hid);
	}

	@Override
	public Hotel getHotelById(String hid) {
		return hotelRepository.getHotelById(hid);
	}

	@Override
	public int updateHotel(String hotId,Hotel hdummy,String cityupd,String name, String address, String desc, double rate, String phone1, String phone2, String rating, String email, String fax) {
		
		return hotelRepository.updateHotel(hotId,hdummy,cityupd,name,address,desc,rate,phone1,phone2,rating,email,fax);
	}

	@Override
	public int deletehotel(String hid) {
		
		return hotelRepository.deleteHotel(hid);
	}

	@Override
	public boolean roomCheck(String rid) {
		
		return hotelRepository.roomcheck(rid);
	}

	@Override
	public RoomDetails addrooms(RoomDetails room) {
		return hotelRepository.addrooms(room);
	}

	@Override
	public List<RoomDetails> viewAllRooms() {
		
		return hotelRepository.viewAllRooms();
	}

	@Override
	public RoomDetails getRoomById(String rid) {
		
		return hotelRepository.getRoomById(rid);
	}

	@Override
	public int updateRoom(String rid, int avail, String rno, String rtype,
			float rate) {
		
		return hotelRepository.updateRooms(rid, avail,rno,rtype,rate);
	}

	@Override
	public int deleteroom(String rid) {
		
		return hotelRepository.deleteroom(rid);
	}

	@Override
	public int deleteRoomByHotelId(String hid) {
		
		return hotelRepository.deleteRoomByHotelId(hid);
	}

	@Override
	public List<BookingDetails> getBookingsByDate(String date) {
		
		return hotelRepository.getBookingsByDate(date);
	}


	

}
