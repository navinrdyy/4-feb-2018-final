package com.cg.exception;

public class HotelException extends Exception{

	public HotelException() {
		
	}

	public HotelException(String message) {
		super(message);
		
	}
	

}
