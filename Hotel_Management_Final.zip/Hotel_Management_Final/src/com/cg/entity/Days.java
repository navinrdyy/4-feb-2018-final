package com.cg.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Days implements Serializable {
	@Id
	private int booking_id;
	private String room_id;
	private String user_id;
	
	
	@NotEmpty(message="Date is mandatory")
	
	private String booked_from;
	
	@NotEmpty(message="Date is mandatory")

	private String boooked_to;
	
	private int no_of_adults;
	private int no_of_children;
	private double amount;
	private String hotel_id;
	/*@NotEmpty(message="Days are mandatory")*/
	//@Pattern(regexp="[0-9]{1,3}$",message="please follow the pattern")
	private int no_of_days;
	
	public int getBooking_id() {
		return booking_id;
	}
	public void setBooking_id(int booking_id) {
		this.booking_id = booking_id;
	}
	public String getRoom_id() {
		return room_id;
	}
	public void setRoom_id(String room_id) {
		this.room_id = room_id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getBooked_from() {
		return booked_from;
	}
	public void setBooked_from(String booked_from) {
		this.booked_from = booked_from;
	}
	public String getBoooked_to() {
		return boooked_to;
	}
	public void setBoooked_to(String boooked_to) {
		this.boooked_to = boooked_to;
	}
	public int getNo_of_adults() {
		return no_of_adults;
	}
	public void setNo_of_adults(int no_of_adults) {
		this.no_of_adults = no_of_adults;
	}
	public int getNo_of_children() {
		return no_of_children;
	}
	public void setNo_of_children(int no_of_children) {
		this.no_of_children = no_of_children;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getHotel_id() {
		return hotel_id;
	}
	public void setHotel_id(String hotel_id) {
		this.hotel_id = hotel_id;
	}
	public int getNo_of_days() {
		return no_of_days;
	}
	public void setNo_of_days(int no_of_days) {
		this.no_of_days = no_of_days;
	}
	public Days() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Days(String room_id, String user_id, String booked_from,
			String boooked_to, int no_of_adults, int no_of_children,
			double amount, String hotel_id, int no_of_days) {
		super();
		this.room_id = room_id;
		this.user_id = user_id;
		this.booked_from = booked_from;
		this.boooked_to = boooked_to;
		this.no_of_adults = no_of_adults;
		this.no_of_children = no_of_children;
		this.amount = amount;
		this.hotel_id = hotel_id;
		this.no_of_days = no_of_days;
	}
	
	
	
}
