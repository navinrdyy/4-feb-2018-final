package com.cg.dao;

import java.util.List;

import com.cg.entity.BookingDetails;
import com.cg.entity.Days;
import com.cg.entity.Hotel;
import com.cg.entity.RoomDetails;
import com.cg.entity.Users;




public interface HotelRepository {
	public abstract List<BookingDetails> bookingstatus(String userid1, String hotelid1,String roomid1);
	public abstract List<Hotel> loadAllhotels();
	public abstract Users check(Users user);
	int save(Days booking,String strdate,String strdate2,String hotelid1,String roomid1,String userid1,int days1);
	public abstract Users save(Users user);
	public abstract List<RoomDetails> loadAllrooms(String id);
	
	
	
	//---------------------ADMIN-----------------------------------
	
	List<Hotel> viewAllHotels();

	List<RoomDetails> viewRooms(String hid);

	Hotel addHotels(Hotel hotel);

	boolean hotelCheck(String hid);

	List<BookingDetails> viewAllBookings(String hid);

	Hotel getHotelById(String hid);

	int updateHotel(String hotId, Hotel hdummy, String cityupd, String name, String address, String desc, double rate, String phone1, String phone2, String rating, String email, String fax);

	int deleteHotel(String hid);

	boolean roomcheck(String rid);

	RoomDetails addrooms(RoomDetails room);

	List<RoomDetails> viewAllRooms();

	RoomDetails getRoomById(String rid);

	int updateRooms(String rid, int avail, String rno, String rtype, float rate);

	int deleteroom(String rid);

	int deleteRoomByHotelId(String hid);

	List<BookingDetails> getBookingsByDate(String date);
	
	
	
	
}
